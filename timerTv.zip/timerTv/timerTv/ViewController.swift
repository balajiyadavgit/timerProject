//
//  ViewController.swift
//  timerWithTable
//
//  Created by Balaji Yadav on 2/25/19.
//  Copyright © 2019 Balaji Yadav. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var laps:[String] = []
    var timer:Timer?
    var count = 0.0
    var minutes:Int = 0
    var seconds:Int = 0
    var milliSeconds:Int = 0
    var timerString = ""
    
    var startTimer:Bool = true
    var lapTimer:Bool = false
    
    @IBOutlet weak var timerTableView: UITableView!
    
 
    @IBOutlet weak var timerLabel: UILabel!
  
    
    @IBOutlet weak var startBtn: UIButton!
 
    @IBOutlet weak var lapBtn: UIButton!
  
    @IBOutlet weak var resetBtn: UIButton!
    
   
    
   
   
    @IBAction func onStartBtn(_ sender: Any) {
    
    
        if startTimer == true{
            timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(onTimerAction), userInfo:nil , repeats: true)
            
            startTimer = false
            startBtn.setImage(UIImage(named: "pause.png"), for: UIControl.State.normal)
//            lapBtn.setImage(UIImage(named: "lap.png") ,for: UIControl.State.normal)
            
            lapTimer = true
            
            
        }else{
            
            timer?.invalidate()
            
            startTimer = true
            startBtn.setImage(UIImage(named: "play.png"), for: UIControl.State.normal)
            lapTimer = false
            
        }
        
        
    }
        
  
    @IBAction func onLapBtn(_ sender: Any) {
    
        if lapTimer == true{
            laps.insert(timerString, at: 0)
            timerTableView.reloadData()
            
            
        }
    
    
    }
    
    
    @IBAction func onResetBtn(_ sender: Any) {
        if startTimer == true{
            
            milliSeconds = 0
            seconds = 0
            minutes = 0
            
            timerString = "00:00:00"
            timerLabel.text = timerString
        }
    
    
    
    }
    
    
    
    @objc func onTimerAction(){
        
        milliSeconds += 1
        if milliSeconds == 100{
            seconds += 1
            milliSeconds = 0
        }
        if seconds == 60{
            minutes += 1
            seconds = 0
            
        }
        
        let milliSecondsString = milliSeconds > 9 ? "\(milliSeconds)" : "0\(milliSeconds)"
        let secondsString = seconds > 9 ? "\(seconds)" : "0\(seconds)"
        let minutesString = minutes > 9 ? "\(minutes)" : "0\(minutes)"
        
        timerString = "\(minutesString):\(secondsString):\(milliSeconds)"
        
        timerLabel.text = timerString
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return laps.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = UITableViewCell(style: UITableViewCell.CellStyle.value1, reuseIdentifier: "balu")
        cell.textLabel!.text = "Lap \(indexPath.row)"
        cell.detailTextLabel?.text = laps[indexPath.row]
        return cell
    }
    
    
}


